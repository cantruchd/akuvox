"""Custom integration to integrate akuvox with Home Assistant.

For more details about this integration, please refer to
https://github.com/nimroddolev/akuvox
"""
from __future__ import annotations

from homeassistant.config_entries import ConfigEntry
from homeassistant.const import Platform
from homeassistant.core import HomeAssistant
from homeassistant.helpers.aiohttp_client import async_get_clientsession
from homeassistant.components import webhook as wb
from aiohttp import web as aio_web

from .config_flow import AkuvoxOptionsFlowHandler
from .api import AkuvoxApiClient
from .const import (
    DOMAIN,
    LOGGER,
    WEBHOOK_ID,
)
from .coordinator import AkuvoxDataUpdateCoordinator

PLATFORMS: list[Platform] = [
    Platform.CAMERA,
    Platform.BUTTON,
    Platform.SENSOR
]

# https://developers.home-assistant.io/docs/config_entries_index/#setting-up-an-entry
async def async_setup_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """Set up this integration using UI."""
    LOGGER.debug("[SETUP] Config entry data keys: %s", list(entry.data.keys()))
    if "token" in entry.data:
        t = entry.data["token"]
        LOGGER.debug("[SETUP] token=%s***%s (len=%s)", t[:5], t[-4:], len(t))
    if "auth_token" in entry.data:
        a = entry.data["auth_token"]
        LOGGER.debug("[SETUP] auth_token=%s***%s (len=%s)", a[:5], a[-4:], len(a))
    if "phone_number" in entry.data:
        LOGGER.debug("[SETUP] phone_number=%s", entry.data["phone_number"])
    if "host" in entry.data:
        LOGGER.debug("[SETUP] host=%s", entry.data["host"])
    if "subdomain" in entry.data:
        LOGGER.debug("[SETUP] subdomain=%s", entry.data["subdomain"])
    hass.data.setdefault(DOMAIN, {})
    hass.data[DOMAIN][entry.entry_id] = coordinator = AkuvoxDataUpdateCoordinator(
        hass=hass,
        client=AkuvoxApiClient(
            session=async_get_clientsession(hass),
            hass=hass,
            entry=entry,
        ),
    )
    await async_update_configuration(hass=hass, entry=entry)

    # Register the webhook BEFORE any API call: the token-sync endpoint must
    # stay alive even if the stored token is invalid/unreachable.
    wb.async_register(
        hass, DOMAIN, "Akuvox token sync", WEBHOOK_ID, async_akuvox_token_webhook
    )

    try:
        await coordinator.async_config_entry_first_refresh()
    except Exception:
        LOGGER.error("[SETUP] Initial refresh failed; webhook stays registered")

    # https://docs.home-assistant.io/docs/integration_fetching_data#coordinated-single-api-poll-for-data-for-all-entities
    await hass.config_entries.async_forward_entry_setups(entry, PLATFORMS)
    entry.async_on_unload(entry.add_update_listener(async_reload_entry))

    return True


async def async_unload_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """Handle removal of an entry."""
    await async_stop_polling(hass)
    if unloaded := await hass.config_entries.async_unload_platforms(entry, PLATFORMS):
        hass.data[DOMAIN].pop(entry.entry_id)
    wb.async_unregister(hass, WEBHOOK_ID)
    return unloaded


async def async_akuvox_token_webhook(hass: HomeAssistant, webhook_id: str, request):
    """Receive token pushed by the patched SmartPlus app."""
    try:
        body = await request.json()
    except Exception:
        body = {}
    token = str(body.get("token", "") or "")
    if not token:
        return aio_web.json_response({"ok": False, "error": "missing token"})
    entries = hass.config_entries.async_entries(DOMAIN)
    if not entries:
        return aio_web.json_response({"ok": False, "error": "no entry"})
    entry = entries[0]
    if entry.data.get("token") != token:
        hass.config_entries.async_update_entry(
            entry,
            data={**entry.data, "token": token, "auth_token": token},
            options={**entry.options, "token": token, "auth_token": token},
        )
        LOGGER.info("[WEBHOOK] Token updated by app (len=%s)", len(token))
        return aio_web.json_response({"ok": True, "updated": True})
    return aio_web.json_response({"ok": True, "updated": False})


async def async_reload_entry(hass: HomeAssistant, entry: ConfigEntry) -> None:
    """Reload config entry."""
    await async_stop_polling(hass)
    await async_unload_entry(hass, entry)
    await async_setup_entry(hass, entry)
    await async_update_configuration(hass, entry)
    await async_start_polling(hass)

# Polling

async def async_stop_polling(hass: HomeAssistant):
    """Stop polling the personal door log API."""
    api_client: AkuvoxApiClient = get_api_client(hass=hass) # type: ignore
    await api_client.async_stop_polling()

async def async_start_polling(hass: HomeAssistant):
    """Stop polling the personal door log API."""
    api_client: AkuvoxApiClient = get_api_client(hass=hass) # type: ignore
    await api_client.async_start_polling_personal_door_log()

def get_api_client(hass: HomeAssistant):
    """Akuvox API Client."""
    for value in hass.data[DOMAIN].values():
        if isinstance(value, AkuvoxDataUpdateCoordinator):
            return value.client
    return None

# Integration options

async def async_options(self, entry: ConfigEntry):
    """Present current configuration options for modification."""
    # Create an options flow handler and return it
    return AkuvoxOptionsFlowHandler(entry)

async def async_options_updated(self, entry: ConfigEntry):
    """Handle updated configuration options and update the entry."""
    # Handle the updated configuration options
    updated_options = entry.options

    # Print the updated options
    LOGGER.debug("Updated Options: %s", str(updated_options))

# Update

async def async_update_configuration(hass: HomeAssistant, entry: ConfigEntry) -> None:
    """Update stored values from configuration."""
    try:
        if entry.options:
            updated_options: dict = entry.options.copy()

            # Wait for image URL?
            updated_options["wait_for_image_url"] = bool(updated_options.get("event_screenshot_options", "") == "wait")

            # Update API & data classes
            coordinator: AkuvoxDataUpdateCoordinator = hass.data[DOMAIN][entry.entry_id]
            client: AkuvoxApiClient = coordinator.client

            LOGGER.debug("Configured values:")
            for key, value in updated_options.items():
                #                           value=value)
                if value:
                    client.update_data(key, value)
                    str_value: str = str(value)
                    if key in ["auth_token", "token"]:
                        length: int = len(str_value)
                        str_value = f"{str_value[0:3]}{'*'*int(length-6)}{str_value[int(length-3):length]}" # type: ignore
                    LOGGER.debug(" - %s = %s", key, str_value)
    except Exception as error:
        LOGGER.warning("Unable to update configuration: %s", str(error))

